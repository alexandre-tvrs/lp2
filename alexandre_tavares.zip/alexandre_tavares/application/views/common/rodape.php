
        <script type="text/javascript" src="<?= base_url() ?>assets/mdb/js/popper.min.js"></script>
        <script type="text/javascript" src="<?= base_url() ?>assets/mdb/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?= base_url() ?>assets/mdb/js/mdb.min.js"></script>
        <script type="text/javascript" src="<?= base_url() ?>assets/js/util.js"></script>
        <script type="text/javascript" src="<?= base_url() ?>assets/js/contas.js"></script>

    </body>
</html>