<div style="height: 100vh">
    <div class="flex-center flex-column">

        <h3 class="mb-5">Controle Financeiro Pessoal</h3>

        <form class="text-center border border-light p-5" method="POST">

            <p class="h4 mb-4">Entrar</p>
            <input type="email" id="email"  name="email" class="form-control mb-4" placeholder="E-mail">
            <input type="password" id="senha" name="senha"  class="form-control mb-4" placeholder="Senha">

            <button class="btn btn-info btn-block my-4" type="submit">Enviar</button>
            
            <p class="red-text"><?= $error ? 'Dados de acesso incorretos.' : '' ?></p>
        </form>

    </div>
</div>